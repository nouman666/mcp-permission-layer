# Current verified hardening revision

Read **HARDENING.md** first. The delivered source commit is in HARDENING_RELEASE.json.
79 tests pass, including a live stdio fixture with 12 explicit assertions. No system-wide isolation is claimed.

# MCP Permission Layer — Reviewer 1 + Reviewer 2 + Reviewer 3 Revision (v1.4-r3c2)

Research artifact accompanying the revised manuscript **“Argument-Aware Runtime Least-Privilege Enforcement Against Tool-Poisoning-Induced Actions in MCP-Based Agentic Systems.”**

This revision preserves Reviewer 1–2 corrections and implements Reviewer 3’s requested separation of permission-inference validity from policy-profile effectiveness, mechanism-faithfulness checks, explicit interception boundaries, and external-provenance challenge evidence. The primary research object is the **automatic capability-inference mechanism** that maps concrete MCP tool names and recursively structured arguments to behavioural capability requirements before a default-deny policy decision.

## Reviewer 1 changes implemented

- **Comment 1 — fail-closed structured arguments:** recursive dict/list traversal, path/domain canonicalization, split host/domain extraction, unfamiliar write-intent handling, broader sensitive-path variants, and fail-closed treatment of unresolved restricted resources. See `src/inference.py`, `src/checker.py`, and the reviewer-marked unit tests.
- **Comment 2 — threat boundary:** addressed in the revised manuscript. This client-side gate controls requests visible at the call boundary; it does not sandbox a malicious upstream server implementation.
- **Comment 3 — adaptive/external-validity boundaries:** `datasets/adaptive_boundaries_v2.json` (48 malicious / 24 benign) explicitly covers the reviewer-identified parser, schema, canonicalization, extraction, and semantic-inference boundaries. `datasets/external_schema_cases.json` contains public-schema-shaped cases; provenance is documented in `datasets/PROVENANCE.md`.
- **Comment 4 — ASK experiment:** reported mode is now `simulated_approval`, not a human-operated study. The artificial 50 ms delay was removed. `--mode interactive` remains optional and is not used for the reported revised table.
- **Comment 5 — utility metric:** revised outputs use **BCAR (Benign Call Allow Rate)**; it is explicitly a call-level allowance rate, not task completion.
- **Comment 6 — baseline/ablation interpretation:** baselines are controlled reference systems; baselines and component ablations are repeated on the untouched organic hold-out in `scripts/run_revision_evaluation.py`.
- **Comment 7 — uncertainty:** class-stratified bootstrap preserves class denominators; zero-event studies report one-sided 95% binomial upper bounds.
- **Comment 8 — timing/reproducibility:** checker-only, local proxy + synchronous logging, and live end-to-end timing are separated. The deterministic stress generator, pinned dependency file, raw per-case decisions, release identifier, and SHA-256 manifest are included.
- **Comment 9 — novelty positioning:** addressed in the revised manuscript; the artifact itself is labeled around the inference mechanism rather than claiming runtime-proxy novelty.

## Quick reproduction

```bash
python -m pip install -r requirements-lock.txt
python scripts/generate_stress_dataset.py
python scripts/build_reviewer_boundary_sets.py
python -m pytest -q
python scripts/run_revision_evaluation.py
python scripts/run_ask_study.py
python scripts/run_reviewer3_validation.py
```

For the live stdio MCP path (requires the pinned MCP runtime and external runtime prerequisites):

```bash
python scripts/run_live_mcp_eval.py
```

## Revised evaluation snapshot

Under `limited_network`:

| Split | ASR | BCAR | Attack-blocking F1 |
|---|---:|---:|---:|
| Pilot design set (61 malicious / 26 benign) | 1.64% | 76.92% | 94.49% |
| Regenerated 20k stress corpus | 0.00% | 75.01% | 88.89% |
| Organic hold-out (50 malicious / 40 benign) | 0.00% | 100.00% | 100.00% |
| Reviewer boundary v2 (48 malicious / 24 benign) | 0.00% | 100.00% | 100.00% |
| Public-schema-shaped set (5 malicious / 9 benign) | 0.00% | 88.89% | 90.91% |
| Real-MCP-style workflow definitions (12 malicious / 13 benign) | 0.00% | 100.00% | 100.00% |

These are enforcement-boundary call metrics. BCAR is not end-to-end task success. Zero observed malicious successes on finite sets do not imply zero population risk; see `results/REVIEWER2_REVISION_SUMMARY.md` for upper bounds.

## Package layout

```text
src/                     corrected inference/checker/proxy implementation
policies/                YAML profiles
baselines/               controlled lightweight reference systems
tests/                   79 tests including policy typing, launch integrity, inference, configured routing, independent comparator, live outcomes and actual stdio integration
datasets/                revised evaluation sets and provenance
scripts/                 revised generation/evaluation/ASK/live scripts
results/                  revised reports + raw per-case decisions
REPRODUCIBILITY.md        reproduction instructions
RELEASE_ID.txt            local revision identifier
SHA256SUMS.txt            content-hash provenance
```

Original-submission-only items retained for provenance are isolated under `datasets/archive_original_submission/` and `results/archive_original_submission/`; they are not the active revised evaluation outputs.


## Reviewer 2 revision

- Trust boundary is explicitly request-level and assumes faithful upstream operation semantics.
- Targeted renamed-write regression: `datasets/reviewer2_targeted_cases.json`.
- Organic-holdout B1–B4 comparison and full dataset/adaptive provenance are included.
- The three read-only vs limited-network benign live differences are allow-listed HTTP calls (RM-004, RM-005, RM-009), not writes.
- ASK ~50 ms artificial delay is no longer interpreted as human latency.
- Latency reporting records exact timing boundaries, repetitions, operations, and host allocation.
- Release/reproduction details are in `REPRODUCIBILITY.md`; presentation fixes are reflected in the revised manuscript.


## Reviewer 3 revision

Reviewer 3 correctly identified that profile-level ASR/BCAR alone cannot validate the permission-inference mechanism. The revision therefore separates the following evidence:

- **Policy-independent capability inference:** `datasets/reviewer3_official_mechanism_audit.json` contains 27 documented reference-server calls with expected capability labels independent of YAML policies. The corrected frozen inference obtains 27/27 exact category sets (100% exact-set accuracy; micro precision/recall/F1 100%).
- **External-provenance capability challenge:** `datasets/reviewer3_mcptox_external_challenge.json` contains 16 concrete calls instantiated from upstream MCPTox case descriptions. The required-capability case coverage and required-label micro recall are both 100%; three additional conservative labels are inferred. This set is external-provenance but not blinded.
- **Policy enforcement faithfulness:** the four-profile category matrix plus three restriction cases produces 27/27 expected decisions. This checks policy implementation separately from inference validity. An idealized declared-capability/ACL oracle (which bypasses inference and receives the documented label directly) agrees with B4 on 108/108 official-case/profile decisions; it is not presented as a full AgentBound/AGT reimplementation.
- **Interception boundary:** 12/12 calls presented to the configured proxy generated one audit decision each. The artifact explicitly does not claim interception of direct/alternative upstream routes that bypass the proxy.
- **Alternative designs:** the manuscript now distinguishes inferred-capability authorization from declared-capability/server-side designs such as AgentBound and broader governance systems such as AGT. No unsupported head-to-head implementation claim is made.
- **End-to-end task impact:** the manuscript now states explicitly that BCAR and the existing multi-step chains are not a full LLM-agent task-completion benchmark; this remains future work rather than being inferred from call-level results.

Reproduce these checks with `python scripts/run_reviewer3_validation.py`. Raw decisions are in `results/reviewer3_validation_raw.json`.
